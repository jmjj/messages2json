# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 20:43:59 2016

@author: jmjj
"""

import messages2json

def main():
    messages2json.main()

if __name__ == "__main__":
    main()    