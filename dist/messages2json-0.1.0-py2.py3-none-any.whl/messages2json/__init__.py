# -*- coding: utf-8 -*-

"""
Created on Wed Mar  2 10:56:34 2016

@author: jmjj (Jari Juopperi, jmjj@juopperi.org)
"""

import sys
import os
import argparse
import mailbox
import json


def parse_cmd_line_args(arg_str: str = '') -> argparse.Namespace:
    """
        Parse the command line arguments
    """

    parser = argparse.ArgumentParser(description=
                                     'Convert e-mail messages to JSON format')
    parser.add_argument('--input', dest='in_f_or_d', action='store',
                        default="stdin", help='input file or directory')
    parser.add_argument('--output', dest='out_f_or_d', action='store',
                        default="stdout", help='output file or directory')
    parser.add_argument('--body', dest='include_body', action='store_true',
                        default=False, help='include the body of the message,\
                        by default only headers are converted')
    parser.add_argument('--format', dest='format', action='store',
                        default="json", help='the format of input messages')
    parser.add_argument('--force', dest='force_save', action='store_true',
                        default=False,
                        help='Overwrite the output files even if they exist')
    print(sys.argv) 
    args = parser.parse_args(sys.argv)

    return args


def expand_paths(source: str, destination: str) -> dict:
    """
        Expand the given input file/directory to a list of absolute paths
        to files to be processed. Expand the give ouput file/directory to
        a list of absolute paths.

        Verify that the input files exists and are readable. Verify that the
        verify that the output directory exists and is writable.
    """

    expanded_sources = []
    input_output_map = {}
    abs_source_path = ""
    

    # Expand the source of the messages to list of absolute paths
    if source == 'stdin':
        expanded_sources.append(source)
    else:
        abs_source_path = os.path.expanduser(source)
        if os.path.isdir(abs_source_path):
            expanded_sources.extend(collect_file_paths(abs_source_path))
        elif os.path.isfile(abs_source_path):
            expanded_sources.append(abs_source_path)
        else:
            print("The source {} is not file or directory !".format(abs_source_path))
            sys.exit(1)

    # Create a mapping between input and output file paths. Assing empty
    # string for each outpu path at this stage of processing.
    for path in expanded_sources:
        input_output_map[path] = ''

    # Expand the destination of the messages to absolute paths
    if destination == 'stdout':
        for path in input_output_map.keys():
            input_output_map[path] = 'stdout'
    else:
         path = os.path.expanduser(destination)        
         if os.path.isdir(path): 
            if source == "stdin":
                print("When reading input fron stdin, the output file must defined with --output !")
                sys.exit(1)
            else:
                for in_file_path in input_output_map.keys():
                    input_output_map[in_file_path] = path + "/" + os.path.basename(in_file_path)
         else:
            if len(input_output_map.keys()) != 1:
                print("Multiple input files can not be mapped to a singe output file !")
                sys.exit(1)
            else:
                 input_output_map[abs_source_path] = os.path.expanduser(path.absolute)
            
    return input_output_map

def collect_file_paths(dir_path: str) -> list:
    """
        Create list of absolute paths of files in given directory
        and it's subdirectories
    """

    list_of_paths = []
    for root, dirs, files in os.walk(dir_path):
        #print(root,dirs,files)
        list_of_paths.extend([root+'/'+x for x in files])
    #print("*** List of input paths ***")    
    #print(list_of_paths)
    return list_of_paths


def process_files(io_map: dict, msg_content_format: str, force: bool, body: bool) -> None:
    """
        Convert a set of files

        Arguments:
        in_file_list:     Absolute paths of files to be processed.
        content_format:   The input format of the messages.

        Output: none
    """

    for mail_file in io_map.keys():
        list_of_messages = []
        for message in mailbox.mbox(mail_file):
            list_of_messages.append(process_one_message(message))
        send_messages_out(io_map[mail_file], list_of_messages,
                          msg_content_format, force)



def process_one_message(message: mailbox.mboxMessage) -> dict:
    """
       Process one mailbox message.

       Arguments:
       message: Mailbox message to be processed.

       Output: Dictionary that contains the content of the message.
    """

    temp_dict = {}
    for field in message.keys():
        temp_dict[field] = message[field]

    return temp_dict

def send_messages_out(out_file: str, list_of_messages: list,
                      msg_content_format: str, force: bool) -> None:
    """
        Dump messages from one input file to output file in JSON fomat.
    """

    file_mode = 'x'
    if out_file == "stdout":
        print(json.dumps(list_of_messages))
    else:
        if force:
            file_mode = 'w'
        else:
            file_mode = 'x'
        try:        
            with open(out_file, mode=file_mode, encoding='UTF-8') as out_file_pointer:
                print(json.dumps(list_of_messages), file=out_file_pointer)
        except Exception as inst:
            print("Can't write to ouput file: {}".format(inst))
            sys.exit(1)

def main():
    """
        The top level function of the program
    """

    args = parse_cmd_line_args()
    io_map = expand_paths(args.in_f_or_d, args.out_f_or_d)
    process_files(io_map, args.format, args.force_save, args.include_body)


if __name__ == "__main__":
    main()
