E-mail to JSON message conveer.
===============================

version number: 0.0.1
author: Jari Juopperi

Overview
--------

A program that can be used to convert messages stored in various mailbox formats into JSON format.

Installation / Usage
--------------------

To install use pip:

    $ pip install messages2json


Or clone the repo:

    $ git clone https://github.com/jmjj/messages2json.git
    $ python setup.py install

Contributing
------------

TBD

Example
-------

TBD

